<?php
/**
 * The template for displaying content when no posts are found
 *
 * @package СоюзБассейнСтрой
 */
?>

<article id="post-0" <?php post_class(); ?>>
    <header class="entry-header">
        <h2 class="entry-title"><?php _e('Ничего не найдено', 'soyuz-bassein-stroy'); ?></h2>
    </header>
    
    <div class="entry-content">
        <p class="text-muted">
            <?php _e('К сожалению, по вашему запросу ничего не найдено. Попробуйте воспользоваться поиском или перейдите на главную страницу.', 'soyuz-bassein-stroy'); ?>
        </p>
        
        <?php get_search_form(); ?>
        
        <div class="mt-4">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary-custom">
                <i class="bi bi-house-door me-2"></i><?php _e('На главную', 'soyuz-bassein-stroy'); ?>
            </a>
        </div>
    </div>
</article>
