<?php
/**
 * The template for displaying posts
 *
 * @package СоюзБассейнСтрой
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('card service-card h-100'); ?>>
    <?php if (has_post_thumbnail()) : ?>
        <div class="overflow-hidden" style="height: 200px;">
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail('medium', array('class' => 'img-fluid w-100 h-100 object-fit-cover')); ?>
            </a>
        </div>
    <?php else: ?>
        <div class="bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
            <i class="bi bi-image text-muted fs-1"></i>
        </div>
    <?php endif; ?>
    
    <div class="card-body">
        <header class="entry-header mb-3">
            <?php the_title('<h3 class="h5 card-title"><a href="' . esc_url(get_permalink()) . '" class="text-decoration-none text-dark">', '</a></h3>'); ?>
            
            <div class="entry-meta small text-muted">
                <span class="posted-on"><i class="bi bi-calendar3 me-1"></i><?php echo get_the_date(); ?></span>
            </div>
        </header>
        
        <div class="entry-content">
            <p class="card-text text-muted"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
        </div>
        
        <footer class="entry-footer mt-3">
            <a href="<?php the_permalink(); ?>" class="btn btn-outline-primary btn-sm">
                <?php _e('Подробнее', 'soyuz-bassein-stroy'); ?> <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </footer>
    </div>
</article>
