<?php
/**
 * СоюзБассейнСтрой Theme Functions
 * 
 * @package СоюзБассейнСтрой
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Define theme constants
 */
define('SOYUZ_VERSION', '1.0.0');
define('SOYUZ_DIR', get_template_directory());
define('SOYUZ_URI', get_template_directory_uri());

/**
 * Enqueue scripts and styles
 */
function soyuz_scripts() {
    // Bootstrap 5 CSS
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', array(), '5.3.0');
    
    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap', array(), null);
    
    // Bootstrap Icons
    wp_enqueue_style('bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css', array(), '1.10.0');
    
    // Main stylesheet
    wp_enqueue_style('soyuz-style', get_stylesheet_uri(), array(), SOYUZ_VERSION);
    
    // Bootstrap 5 JS
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', array('jquery'), '5.3.0', true);
    
    // Custom JS
    wp_enqueue_script('soyuz-custom', SOYUZ_URI . '/js/custom.js', array('jquery', 'bootstrap-js'), SOYUZ_VERSION, true);
    
    // Localize script with AJAX URL
    wp_localize_script('soyuz-custom', 'soyuz_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('soyuz-nonce')
    ));
}
add_action('wp_enqueue_scripts', 'soyuz_scripts');

/**
 * Register navigation menus
 */
function soyuz_register_menus() {
    register_nav_menus(array(
        'primary' => __('Главное меню', 'soyuz-bassein-stroy'),
        'footer' => __('Меню в подвале', 'soyuz-bassein-stroy'),
    ));
}
add_action('after_setup_theme', 'soyuz_register_menus');

/**
 * Theme setup
 */
function soyuz_setup() {
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails
    add_theme_support('post-thumbnails');
    
    // Add custom image sizes
    add_image_size('portfolio-large', 800, 600, true);
    add_image_size('service-thumb', 400, 300, true);
    
    // Register custom menus
    soyuz_register_menus();
    
    // HTML5 support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Custom background support
    add_theme_support('custom-background');
}
add_action('after_setup_theme', 'soyuz_setup');

/**
 * Register widget areas
 */
function soyuz_widgets_init() {
    register_sidebar(array(
        'name'          => __('Боковая панель', 'soyuz-bassein-stroy'),
        'id'            => 'sidebar-1',
        'description'   => __('Добавьте виджеты здесь.', 'soyuz-bassein-stroy'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Подвал - колонка 1', 'soyuz-bassein-stroy'),
        'id'            => 'footer-1',
        'before_widget' => '<div class="footer-widget mb-4">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Подвал - колонка 2', 'soyuz-bassein-stroy'),
        'id'            => 'footer-2',
        'before_widget' => '<div class="footer-widget mb-4">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Подвал - колонка 3', 'soyuz-bassein-stroy'),
        'id'            => 'footer-3',
        'before_widget' => '<div class="footer-widget mb-4">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'soyuz_widgets_init');

/**
 * Custom excerpt length
 */
function soyuz_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'soyuz_excerpt_length');

/**
 * Custom excerpt more
 */
function soyuz_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'soyuz_excerpt_more');

/**
 * Add custom body classes
 */
function soyuz_body_classes($classes) {
    if (!is_singular()) {
        $classes[] = 'hfeed';
    }
    
    if (is_front_page()) {
        $classes[] = 'front-page';
    }
    
    return $classes;
}
add_filter('body_class', 'soyuz_body_classes');

/**
 * Customizer additions
 */
function soyuz_customize_register($wp_customize) {
    // Contact Info Section
    $wp_customize->add_section('soyuz_contact_info', array(
        'title'    => __('Контактная информация', 'soyuz-bassein-stroy'),
        'priority' => 30,
    ));
    
    // Phone Number
    $wp_customize->add_setting('soyuz_phone', array(
        'default'           => '+79677018686',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('soyuz_phone', array(
        'label'   => __('Телефон', 'soyuz-bassein-stroy'),
        'section' => 'soyuz_contact_info',
        'type'    => 'text',
    ));
    
    // Address
    $wp_customize->add_setting('soyuz_address', array(
        'default'           => 'г.Пенза ул.Ленинградская, 6',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('soyuz_address', array(
        'label'   => __('Адрес', 'soyuz-bassein-stroy'),
        'section' => 'soyuz_contact_info',
        'type'    => 'text',
    ));
    
    // Email
    $wp_customize->add_setting('soyuz_email', array(
        'default'           => 'info@союзбассейнстрой.рф',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('soyuz_email', array(
        'label'   => __('Email', 'soyuz-bassein-stroy'),
        'section' => 'soyuz_contact_info',
        'type'    => 'email',
    ));
}
add_action('customize_register', 'soyuz_customize_register');

/**
 * Include template tags
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Load additional files
 */
require get_template_directory() . '/inc/custom-functions.php';
