<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package СоюзБассейнСтрой
 */

get_header(); ?>

<main class="main-content py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <div class="py-5">
                    <i class="bi bi-exclamation-triangle display-1 text-warning mb-4"></i>
                    <h1 class="display-3 fw-bold mb-4"><?php _e('404', 'soyuz-bassein-stroy'); ?></h1>
                    <h2 class="h3 mb-4"><?php _e('Страница не найдена', 'soyuz-bassein-stroy'); ?></h2>
                    <p class="lead text-muted mb-5">
                        <?php _e('К сожалению, запрашиваемая страница не существует. Возможно, она была удалена или перемещена.', 'soyuz-bassein-stroy'); ?>
                    </p>
                    
                    <div class="d-flex gap-3 justify-content-center">
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary-custom btn-lg">
                            <i class="bi bi-house-door me-2"></i><?php _e('На главную', 'soyuz-bassein-stroy'); ?>
                        </a>
                        <button class="btn btn-outline-primary btn-lg" onclick="history.back()">
                            <i class="bi bi-arrow-left me-2"></i><?php _e('Назад', 'soyuz-bassein-stroy'); ?>
                        </button>
                    </div>
                    
                    <!-- Search Form -->
                    <div class="mt-5 p-4 bg-light rounded">
                        <h3 class="h5 mb-3"><?php _e('Поиск по сайту', 'soyuz-bassein-stroy'); ?></h3>
                        <?php get_search_form(); ?>
                    </div>
                    
                    <!-- Quick Links -->
                    <div class="mt-5">
                        <h3 class="h5 mb-3"><?php _e('Возможно, вам будут полезны:', 'soyuz-bassein-stroy'); ?></h3>
                        <div class="row g-3 justify-content-center">
                            <div class="col-md-4">
                                <a href="<?php echo esc_url(home_url('/#services')); ?>" class="card service-card text-decoration-none">
                                    <div class="card-body text-center">
                                        <i class="bi bi-droplet-fill feature-icon"></i>
                                        <h5 class="card-title"><?php _e('Наши услуги', 'soyuz-bassein-stroy'); ?></h5>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?php echo esc_url(home_url('/#portfolio')); ?>" class="card service-card text-decoration-none">
                                    <div class="card-body text-center">
                                        <i class="bi bi-images feature-icon"></i>
                                        <h5 class="card-title"><?php _e('Портфолио', 'soyuz-bassein-stroy'); ?></h5>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?php echo esc_url(home_url('/#contact')); ?>" class="card service-card text-decoration-none">
                                    <div class="card-body text-center">
                                        <i class="bi bi-envelope-fill feature-icon"></i>
                                        <h5 class="card-title"><?php _e('Контакты', 'soyuz-bassein-stroy'); ?></h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
