<?php
/**
 * The template for displaying pages
 *
 * @package СоюзБассейнСтрой
 */

get_header(); ?>

<main class="main-content py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <?php
                while (have_posts()) :
                    the_post();
                ?>
                
                <article id="post-<?php the_ID(); ?>" <?php post_class('card border-0 shadow-sm'); ?>>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="card-img-top overflow-hidden rounded-top" style="max-height: 400px;">
                            <?php the_post_thumbnail('large', array('class' => 'img-fluid w-100 h-100 object-fit-cover')); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="card-body p-4 p-lg-5">
                        <header class="entry-header mb-4">
                            <h1 class="entry-title fw-bold"><?php the_title(); ?></h1>
                        </header>
                        
                        <div class="entry-content">
                            <?php the_content(); ?>
                        </div>
                    </div>
                </article>
                
                <?php
                // If comments are open or we have at least one comment, load up the comment template.
                if (comments_open() || get_comments_number()) :
                    comments_template();
                endif;
                
                endwhile;
                ?>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
