<?php
/**
 * The template for displaying search results pages
 *
 * @package СоюзБассейнСтрой
 */

get_header(); ?>

<main class="main-content py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <header class="page-header mb-4">
                    <h1 class="page-title fw-bold">
                        <?php
                        printf(
                            __('Результаты поиска по запросу: %s', 'soyuz-bassein-stroy'),
                            '<span class="text-primary">' . get_search_query() . '</span>'
                        );
                        ?>
                    </h1>
                </header>
                
                <?php if (have_posts()) : ?>
                    
                    <div class="row g-4">
                        <?php while (have_posts()) : the_post(); ?>
                            
                            <div class="col-md-6">
                                <article id="post-<?php the_ID(); ?>" <?php post_class('card service-card h-100'); ?>>
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="overflow-hidden" style="height: 200px;">
                                            <?php the_post_thumbnail('medium', array('class' => 'img-fluid w-100 h-100 object-fit-cover')); ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                                            <i class="bi bi-image text-muted fs-1"></i>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="card-body">
                                        <h3 class="h5 card-title">
                                            <a href="<?php the_permalink(); ?>" class="text-decoration-none text-dark">
                                                <?php the_title(); ?>
                                            </a>
                                        </h3>
                                        <p class="card-text text-muted"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                                        <a href="<?php the_permalink(); ?>" class="btn btn-outline-primary btn-sm">
                                            <?php _e('Подробнее', 'soyuz-bassein-stroy'); ?>
                                        </a>
                                    </div>
                                    
                                    <div class="card-footer bg-white border-0 pt-0">
                                        <small class="text-muted">
                                            <i class="bi bi-calendar3 me-1"></i><?php echo get_the_date(); ?>
                                        </small>
                                    </div>
                                </article>
                            </div>
                            
                        <?php endwhile; ?>
                    </div>
                    
                    <!-- Pagination -->
                    <nav class="navigation pagination mt-5" aria-label="Записи">
                        <?php
                        the_posts_pagination(array(
                            'mid_size'  => 2,
                            'prev_text' => __('← Назад', 'soyuz-bassein-stroy'),
                            'next_text' => __('Вперед →', 'soyuz-bassein-stroy'),
                        ));
                        ?>
                    </nav>
                    
                <?php else : ?>
                    
                    <div class="alert alert-info">
                        <p class="mb-0">
                            <i class="bi bi-info-circle-fill me-2"></i>
                            <?php _e('По вашему запросу ничего не найдено. Попробуйте изменить поисковый запрос.', 'soyuz-bassein-stroy'); ?>
                        </p>
                    </div>
                    
                    <!-- Search Form -->
                    <div class="mt-4">
                        <?php get_search_form(); ?>
                    </div>
                    
                <?php endif; ?>
            </div>
            
            <div class="col-lg-4">
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
