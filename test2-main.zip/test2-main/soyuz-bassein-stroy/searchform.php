<?php
/**
 * The template for displaying search form
 *
 * @package СоюзБассейнСтрой
 */
?>

<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
    <div class="input-group">
        <input type="search" class="form-control" placeholder="<?php esc_attr_e('Поиск...', 'soyuz-bassein-stroy'); ?>" value="<?php echo get_search_query(); ?>" name="s" aria-label="Search">
        <button class="btn btn-primary-custom" type="submit">
            <i class="bi bi-search"></i>
            <span class="d-none d-sm-inline ms-1"><?php _e('Найти', 'soyuz-bassein-stroy'); ?></span>
        </button>
    </div>
</form>
