/**
 * СоюзБассейнСтрой Theme Custom JavaScript
 * 
 * @package СоюзБассейнСтрой
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Smooth scroll for anchor links
        $('a[href^="#"]').on('click', function(e) {
            var target = $(this.getAttribute('href'));
            if (target.length) {
                e.preventDefault();
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 80
                }, 1000);
            }
        });
        
        // Contact form submission
        $('#contactForm').on('submit', function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            var originalText = $submitBtn.html();
            
            // Disable button during submission
            $submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Отправка...');
            
            $.ajax({
                url: soyuz_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'soyuz_contact_form',
                    nonce: soyuz_ajax.nonce,
                    name: $('#name').val(),
                    phone: $('#phone').val(),
                    email: $('#email').val(),
                    message: $('#message').val()
                },
                success: function(response) {
                    if (response.success) {
                        $form.html('<div class="alert alert-success text-center"><i class="bi bi-check-circle-fill me-2"></i>' + response.data.message + '</div>');
                    } else {
                        alert(response.data.message || 'Произошла ошибка при отправке');
                        $submitBtn.prop('disabled', false).html(originalText);
                    }
                },
                error: function() {
                    alert('Произошла ошибка при отправке заявки. Попробуйте позже.');
                    $submitBtn.prop('disabled', false).html(originalText);
                }
            });
        });
        
        // Phone input mask
        $('#phone').on('input', function() {
            var value = $(this).val().replace(/\D/g, '');
            if (value.length > 0) {
                if (value.charAt(0) === '7' || value.charAt(0) === '8') {
                    value = value.substring(1);
                }
                var formatted = '+7';
                if (value.length > 0) formatted += ' (' + value.substring(0, 3);
                if (value.length > 3) formatted += ') ' + value.substring(3, 6);
                if (value.length > 6) formatted += '-' + value.substring(6, 8);
                if (value.length > 8) formatted += '-' + value.substring(8, 10);
                $(this).val(formatted);
            }
        });
        
        // Navbar background on scroll
        $(window).on('scroll', function() {
            if ($(window).scrollTop() > 50) {
                $('.navbar').addClass('shadow');
            } else {
                $('.navbar').removeClass('shadow');
            }
        });
        
        // Animate elements on scroll
        var $animateElements = $('.service-card, .testimonial-card, .portfolio-item');
        
        function checkAnimation() {
            $animateElements.each(function() {
                var elementTop = $(this).offset().top;
                var windowBottom = $(window).scrollTop() + $(window).height();
                
                if (elementTop < windowBottom - 50) {
                    $(this).addClass('animate__animated animate__fadeInUp');
                }
            });
        }
        
        $(window).on('scroll', checkAnimation);
        checkAnimation();
        
        // Lazy loading for images
        var lazyImages = document.querySelectorAll('img[data-src]');
        
        if ('IntersectionObserver' in window) {
            var imageObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        var img = entry.target;
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        imageObserver.unobserve(img);
                    }
                });
            });
            
            lazyImages.forEach(function(img) {
                imageObserver.observe(img);
            });
        }
        
        // Mobile menu close on click
        $('.navbar-nav .nav-link').on('click', function() {
            if ($(window).width() < 992) {
                $('.navbar-collapse').collapse('hide');
            }
        });
        
    });
    
})(jQuery);
