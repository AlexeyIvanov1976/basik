<?php
/**
 * The template for displaying single posts
 *
 * @package СоюзБассейнСтрой
 */

get_header(); ?>

<main class="main-content py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <?php
                while (have_posts()) :
                    the_post();
                ?>
                
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header mb-4">
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="mb-4">
                                <?php the_post_thumbnail('large', array('class' => 'img-fluid rounded shadow-sm w-100')); ?>
                            </div>
                        <?php endif; ?>
                        
                        <h1 class="entry-title fw-bold"><?php the_title(); ?></h1>
                        
                        <div class="entry-meta text-muted small mb-4">
                            <span class="posted-on"><i class="bi bi-calendar3 me-1"></i><?php echo get_the_date(); ?></span>
                            <span class="byline ms-3"><i class="bi bi-person me-1"></i><?php echo get_the_author(); ?></span>
                        </div>
                    </header>
                    
                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                    
                    <footer class="entry-footer mt-5">
                        <?php
                        $categories = get_the_category();
                        if ($categories) {
                            echo '<div class="mb-3">';
                            echo '<strong>Категории:</strong> ';
                            foreach ($categories as $category) {
                                echo '<a href="' . esc_url(get_category_link($category->term_id)) . '" class="badge bg-primary me-2">' . esc_html($category->name) . '</a>';
                            }
                            echo '</div>';
                        }
                        
                        $tags = get_the_tags();
                        if ($tags) {
                            echo '<div>';
                            echo '<strong>Теги:</strong> ';
                            foreach ($tags as $tag) {
                                echo '<a href="' . esc_url(get_tag_link($tag->term_id)) . '" class="badge bg-secondary me-2">' . esc_html($tag->name) . '</a>';
                            }
                            echo '</div>';
                        }
                        ?>
                    </footer>
                </article>
                
                <!-- Post Navigation -->
                <nav class="navigation post-navigation mt-5" aria-label="Навигация по записям">
                    <div class="row">
                        <div class="col-6">
                            <?php previous_post_link('%link', '<i class="bi bi-arrow-left me-2"></i>%title'); ?>
                        </div>
                        <div class="col-6 text-end">
                            <?php next_post_link('%link', '%title<i class="bi bi-arrow-right ms-2"></i>'); ?>
                        </div>
                    </div>
                </nav>
                
                <!-- Comments Section -->
                <?php
                if (comments_open() || get_comments_number()) :
                    comments_template();
                endif;
                ?>
                
                <?php
                endwhile;
                ?>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
