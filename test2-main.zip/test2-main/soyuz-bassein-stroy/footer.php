<?php
/**
 * The footer template
 *
 * @package СоюзБассейнСтрой
 */

$phone = get_theme_mod('soyuz_phone', '+79677018686');
$email = get_theme_mod('soyuz_email', 'info@союзбассейнстрой.рф');
$address = get_theme_mod('soyuz_address', 'г.Пенза ул.Ленинградская, 6');
?>

<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4">
                <h4 class="footer-widget-title">СоюзБассейнСтрой</h4>
                <p>Профессиональное строительство бассейнов любой сложности. Качество, надежность и гарантия на все виды работ.</p>
                <div class="social-links mt-3">
                    <a href="#" class="text-white me-3"><i class="bi bi-whatsapp fs-4"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-telegram fs-4"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-vk fs-4"></i></a>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6 mb-4">
                <h4 class="footer-widget-title">Услуги</h4>
                <ul class="list-unstyled">
                    <li><a href="<?php echo esc_url(home_url('/#services')); ?>" class="text-white text-decoration-none">Строительство бассейнов</a></li>
                    <li><a href="<?php echo esc_url(home_url('/#services')); ?>" class="text-white text-decoration-none">Оборудование для бассейнов</a></li>
                    <li><a href="<?php echo esc_url(home_url('/#services')); ?>" class="text-white text-decoration-none">Обслуживание бассейнов</a></li>
                    <li><a href="<?php echo esc_url(home_url('/#portfolio')); ?>" class="text-white text-decoration-none">Наши работы</a></li>
                    <li><a href="<?php echo esc_url(home_url('/#contact')); ?>" class="text-white text-decoration-none">Контакты</a></li>
                </ul>
            </div>
            
            <div class="col-lg-4 col-md-12 mb-4">
                <h4 class="footer-widget-title">Контакты</h4>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <i class="bi bi-geo-alt-fill me-2"></i>
                        <?php echo esc_html($address); ?>
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-telephone-fill me-2"></i>
                        <a href="tel:<?php echo esc_attr($phone); ?>" class="text-white text-decoration-none"><?php echo esc_html($phone); ?></a>
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-envelope-fill me-2"></i>
                        <a href="mailto:<?php echo esc_attr($email); ?>" class="text-white text-decoration-none"><?php echo esc_html($email); ?></a>
                    </li>
                </ul>
            </div>
        </div>
        
        <hr class="my-4 bg-light">
        
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> СоюзБассейнСтрой. Все права защищены.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0">Разработка сайтов на WordPress</p>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->
<a href="#" class="back-to-top btn btn-primary-custom position-fixed" id="backToTop" style="bottom: 20px; right: 20px; display: none;">
    <i class="bi bi-arrow-up"></i>
</a>

<?php wp_footer(); ?>

<script>
// Back to top button functionality
document.addEventListener('DOMContentLoaded', function() {
    const backToTop = document.getElementById('backToTop');
    
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTop.style.display = 'block';
        } else {
            backToTop.style.display = 'none';
        }
    });
    
    backToTop.addEventListener('click', function(e) {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
</script>

</body>
</html>
