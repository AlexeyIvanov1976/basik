<?php
/**
 * Custom functions for this theme
 *
 * @package СоюзБассейнСтрой
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handle AJAX contact form submission
 */
function soyuz_handle_contact_form() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'soyuz-nonce')) {
        wp_send_json_error(array('message' => 'Ошибка безопасности'));
    }
    
    // Sanitize input data
    $name = sanitize_text_field($_POST['name']);
    $phone = sanitize_text_field($_POST['phone']);
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $message = sanitize_textarea_field($_POST['message']);
    
    // Validate required fields
    if (empty($name) || empty($phone)) {
        wp_send_json_error(array('message' => 'Пожалуйста, заполните обязательные поля'));
    }
    
    // Prepare email
    $to = get_option('admin_email');
    $subject = 'Новая заявка с сайта СоюзБассейнСтрой';
    $body = "Имя: {$name}\n";
    $body .= "Телефон: {$phone}\n";
    $body .= "Email: {$email}\n";
    $body .= "Сообщение: {$message}\n";
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    // Send email
    if (wp_mail($to, $subject, nl2br($body), $headers)) {
        wp_send_json_success(array('message' => 'Спасибо! Ваша заявка отправлена. Мы свяжемся с вами в ближайшее время.'));
    } else {
        wp_send_json_error(array('message' => 'Произошла ошибка при отправке заявки. Попробуйте позже.'));
    }
}
add_action('wp_ajax_soyuz_contact_form', 'soyuz_handle_contact_form');
add_action('wp_ajax_nopriv_soyuz_contact_form', 'soyuz_handle_contact_form');

/**
 * Custom excerpt length
 */
function soyuz_custom_excerpt_length($length) {
    if (is_admin()) {
        return $length;
    }
    return 25;
}
add_filter('excerpt_length', 'soyuz_custom_excerpt_length', 999);

/**
 * Add custom image sizes
 */
function soyuz_additional_image_sizes() {
    add_image_size('hero-image', 1920, 600, true);
    add_image_size('service-card', 400, 300, true);
}
add_action('after_setup_theme', 'soyuz_additional_image_sizes');

/**
 * Modify the main query for portfolio section
 */
function soyuz_pre_get_posts($query) {
    if (!is_admin() && $query->is_main_query() && is_home()) {
        $query->set('posts_per_page', 9);
    }
}
add_action('pre_get_posts', 'soyuz_pre_get_posts');

/**
 * Add schema markup for local business
 */
function soyuz_schema_markup() {
    ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "СоюзБассейнСтрой",
        "url": "https://союзбассейнстрой.рф",
        "telephone": "+79677018686",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "ул.Ленинградская, 6",
            "addressLocality": "Пенза",
            "addressCountry": "RU"
        },
        "openingHours": "Mo-Fr 09:00-18:00",
        "priceRange": "$$"
    }
    </script>
    <?php
}
add_action('wp_head', 'soyuz_schema_markup');

/**
 * Register custom post types
 */
function soyuz_register_post_types() {
    // Portfolio post type
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => __('Портфолио', 'soyuz-bassein-stroy'),
            'singular_name' => __('Проект', 'soyuz-bassein-stroy'),
            'add_new' => __('Добавить проект', 'soyuz-bassein-stroy'),
            'add_new_item' => __('Добавить новый проект', 'soyuz-bassein-stroy'),
            'edit_item' => __('Редактировать проект', 'soyuz-bassein-stroy'),
            'new_item' => __('Новый проект', 'soyuz-bassein-stroy'),
            'view_item' => __('Просмотр проекта', 'soyuz-bassein-stroy'),
            'search_items' => __('Поиск проектов', 'soyuz-bassein-stroy'),
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-images-alt2',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'portfolio'),
    ));
    
    // Services post type
    register_post_type('service', array(
        'labels' => array(
            'name' => __('Услуги', 'soyuz-bassein-stroy'),
            'singular_name' => __('Услуга', 'soyuz-bassein-stroy'),
            'add_new' => __('Добавить услугу', 'soyuz-bassein-stroy'),
            'add_new_item' => __('Добавить новую услугу', 'soyuz-bassein-stroy'),
            'edit_item' => __('Редактировать услугу', 'soyuz-bassein-stroy'),
            'new_item' => __('Новая услуга', 'soyuz-bassein-stroy'),
            'view_item' => __('Просмотр услуги', 'soyuz-bassein-stroy'),
            'search_items' => __('Поиск услуг', 'soyuz-bassein-stroy'),
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-admin-tools',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'services'),
    ));
}
add_action('init', 'soyuz_register_post_types');

/**
 * Flush rewrite rules on theme activation
 */
function soyuz_theme_activation() {
    soyuz_register_post_types();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'soyuz_theme_activation');
