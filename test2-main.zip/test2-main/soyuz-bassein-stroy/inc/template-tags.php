<?php
/**
 * Custom template tags for this theme
 *
 * @package СоюзБассейнСтрой
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Display navigation to next/previous set of posts when applicable.
 */
function soyuz_posts_navigation() {
    the_posts_pagination(array(
        'mid_size'  => 2,
        'prev_text' => __('← Назад', 'soyuz-bassein-stroy'),
        'next_text' => __('Вперед →', 'soyuz-bassein-stroy'),
    ));
}

/**
 * Display Post thumbnail if available
 */
function soyuz_post_thumbnail($size = 'post-thumbnail') {
    if (has_post_thumbnail()) {
        the_post_thumbnail($size, array('class' => 'img-fluid'));
    }
}

/**
 * Display entry meta information
 */
function soyuz_entry_meta() {
    echo '<div class="entry-meta text-muted small">';
    echo '<span class="posted-on"><i class="bi bi-calendar3 me-1"></i>' . get_the_date() . '</span>';
    echo '<span class="byline ms-3"><i class="bi bi-person me-1"></i>' . get_the_author() . '</span>';
    echo '</div>';
}
