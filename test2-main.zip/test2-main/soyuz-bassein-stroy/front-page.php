<?php
/**
 * Template Name: Главная страница
 * The front page template file
 *
 * @package СоюзБассейнСтрой
 */

get_header();

$phone = get_theme_mod('soyuz_phone', '+79677018686');
$email = get_theme_mod('soyuz_email', 'info@союзбассейнстрой.рф');
$address = get_theme_mod('soyuz_address', 'г.Пенза ул.Ленинградская, 6');
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">Строительство бассейнов в Пензе</h1>
                <p class="lead mb-4">Профессиональное проектирование и строительство бассейнов любой сложности. Гарантия качества и надежности.</p>
                <div class="d-flex gap-3">
                    <a href="#contact" class="btn btn-primary-custom btn-lg">Заказать расчет</a>
                    <a href="#portfolio" class="btn btn-outline-light btn-lg">Наши работы</a>
                </div>
            </div>
            <div class="col-lg-6 d-none d-lg-block">
                <img src="<?php echo get_template_directory_uri(); ?>/images/hero-pool.png" alt="Строительство бассейнов" class="img-fluid rounded shadow-lg" onerror="this.style.display='none'">
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="bi bi-shield-check"></i>
                </div>
                <h5>Гарантия качества</h5>
                <p class="text-muted">Гарантия на все виды работ до 5 лет</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="bi bi-clock-history"></i>
                </div>
                <h5>Опыт работы</h5>
                <p class="text-muted">Более 10 лет на рынке строительства</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="bi bi-tools"></i>
                </div>
                <h5>Собственное производство</h5>
                <p class="text-muted">Контроль качества на всех этапах</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="bi bi-wallet2"></i>
                </div>
                <h5>Доступные цены</h5>
                <p class="text-muted">Оптимальное соотношение цена/качество</p>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section id="services" class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Наши услуги</h2>
            <p class="text-muted">Полный комплекс услуг по строительству и обслуживанию бассейнов</p>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="card service-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon">
                            <i class="bi bi-droplet-fill"></i>
                        </div>
                        <h4 class="card-title">Строительство бассейнов</h4>
                        <p class="card-text text-muted">Проектирование и строительство бетонных, композитных и каркасных бассейнов любой формы и размера.</p>
                        <a href="#contact" class="btn btn-outline-primary mt-3">Подробнее</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="card service-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon">
                            <i class="bi bi-gear-fill"></i>
                        </div>
                        <h4 class="card-title">Оборудование для бассейнов</h4>
                        <p class="card-text text-muted">Поставка, монтаж и настройка систем фильтрации, подогрева, освещения и автоматизации.</p>
                        <a href="#contact" class="btn btn-outline-primary mt-3">Подробнее</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="card service-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon">
                            <i class="bi bi-arrow-repeat"></i>
                        </div>
                        <h4 class="card-title">Обслуживание бассейнов</h4>
                        <p class="card-text text-muted">Регулярное техническое обслуживание, чистка, химическая обработка воды и ремонт оборудования.</p>
                        <a href="#contact" class="btn btn-outline-primary mt-3">Подробнее</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="card service-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon">
                            <i class="bi bi-pencil-square"></i>
                        </div>
                        <h4 class="card-title">Проектирование</h4>
                        <p class="card-text text-muted">Разработка индивидуальных проектов с учетом всех особенностей вашего участка и пожеланий.</p>
                        <a href="#contact" class="btn btn-outline-primary mt-3">Подробнее</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="card service-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon">
                            <i class="bi bi-house-add"></i>
                        </div>
                        <h4 class="card-title">Бассейны под ключ</h4>
                        <p class="card-text text-muted">Полный цикл работ от проектирования до сдачи готового объекта с гарантией качества.</p>
                        <a href="#contact" class="btn btn-outline-primary mt-3">Подробнее</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="card service-card h-100">
                    <div class="card-body text-center p-4">
                        <div class="feature-icon">
                            <i class="bi bi-bank"></i>
                        </div>
                        <h4 class="card-title">Общественные бассейны</h4>
                        <p class="card-text text-muted">Строительство крупных спортивных и общественных бассейнов для коммерческих объектов.</p>
                        <a href="#contact" class="btn btn-outline-primary mt-3">Подробнее</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Portfolio Section -->
<section id="portfolio" class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Наши работы</h2>
            <p class="text-muted">Примеры выполненных проектов</p>
        </div>
        
        <div class="row g-4">
            <?php
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => 6,
            );
            $portfolio_query = new WP_Query($args);
            
            if ($portfolio_query->have_posts()) :
                while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
            ?>
            <div class="col-lg-4 col-md-6">
                <div class="portfolio-item card border-0 shadow-sm">
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="overflow-hidden" style="height: 250px;">
                            <?php the_post_thumbnail('portfolio-large', array('class' => 'img-fluid w-100 h-100 object-fit-cover')); ?>
                        </div>
                    <?php else: ?>
                        <div class="bg-secondary d-flex align-items-center justify-content-center" style="height: 250px;">
                            <span class="text-white">Фото проекта</span>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php the_title(); ?></h5>
                        <p class="card-text text-muted"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                    </div>
                </div>
            </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else:
            ?>
            <!-- Placeholder portfolio items -->
            <div class="col-lg-4 col-md-6">
                <div class="portfolio-item card border-0 shadow-sm">
                    <div class="bg-primary bg-gradient d-flex align-items-center justify-content-center" style="height: 250px;">
                        <i class="bi bi-image text-white fs-1"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Частный бассейн в коттедже</h5>
                        <p class="card-text text-muted">Строительство бетонного бассейна с подсветкой и системой подогрева</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="portfolio-item card border-0 shadow-sm">
                    <div class="bg-info bg-gradient d-flex align-items-center justify-content-center" style="height: 250px;">
                        <i class="bi bi-image text-white fs-1"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Спортивный бассейн</h5>
                        <p class="card-text text-muted">Общественный бассейн для спортивного комплекса</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="portfolio-item card border-0 shadow-sm">
                    <div class="bg-success bg-gradient d-flex align-items-center justify-content-center" style="height: 250px;">
                        <i class="bi bi-image text-white fs-1"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Бассейн с зоной SPA</h5>
                        <p class="card-text text-muted">Комплекс с бассейном, джакузи и сауной</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="text-center mt-5">
            <a href="#" class="btn btn-primary-custom btn-lg">Смотреть все работы</a>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Отзывы клиентов</h2>
            <p class="text-muted">Что говорят о нас наши клиенты</p>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="testimonial-card h-100">
                    <div class="mb-3">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                    </div>
                    <p class="mb-4">"Отличная компания! Построили нам прекрасный бассейн за разумные деньги. Все сделали в срок, качество на высоте. Рекомендую!"</p>
                    <div class="d-flex align-items-center">
                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                            <span class="text-white fw-bold">А</span>
                        </div>
                        <div>
                            <h6 class="mb-0">Александр Петров</h6>
                            <small class="text-muted">Частный заказчик</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="testimonial-card h-100">
                    <div class="mb-3">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                    </div>
                    <p class="mb-4">"Заказывали строительство бассейна для нашего отеля. Профессиональный подход, качественное оборудование, отличное сервисное обслуживание."</p>
                    <div class="d-flex align-items-center">
                        <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                            <span class="text-white fw-bold">М</span>
                        </div>
                        <div>
                            <h6 class="mb-0">Мария Иванова</h6>
                            <small class="text-muted">Генеральный директор отеля</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="testimonial-card h-100">
                    <div class="mb-3">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                    </div>
                    <p class="mb-4">"Сотрудничаем уже третий год. Обслуживают наш спортивный комплекс. Всегда оперативно реагируют на любые вопросы. Надежный партнер!"</p>
                    <div class="d-flex align-items-center">
                        <div class="bg-info rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                            <span class="text-white fw-bold">Д</span>
                        </div>
                        <div>
                            <h6 class="mb-0">Дмитрий Сидоров</h6>
                            <small class="text-muted">Директор спорткомплекса</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section id="contact" class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h2 class="fw-bold mb-4">Свяжитесь с нами</h2>
                <p class="mb-4">Оставьте заявку на бесплатную консультацию и расчет стоимости вашего будущего бассейна</p>
                
                <div class="d-flex align-items-start mb-4">
                    <div class="feature-icon me-3 mb-0">
                        <i class="bi bi-geo-alt-fill"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">Наш адрес</h5>
                        <p class="text-muted mb-0"><?php echo esc_html($address); ?></p>
                    </div>
                </div>
                
                <div class="d-flex align-items-start mb-4">
                    <div class="feature-icon me-3 mb-0">
                        <i class="bi bi-telephone-fill"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">Телефон</h5>
                        <p class="text-muted mb-0">
                            <a href="tel:<?php echo esc_attr($phone); ?>" class="text-decoration-none"><?php echo esc_html($phone); ?></a>
                        </p>
                    </div>
                </div>
                
                <div class="d-flex align-items-start mb-4">
                    <div class="feature-icon me-3 mb-0">
                        <i class="bi bi-envelope-fill"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">Email</h5>
                        <p class="text-muted mb-0">
                            <a href="mailto:<?php echo esc_attr($email); ?>" class="text-decoration-none"><?php echo esc_html($email); ?></a>
                        </p>
                    </div>
                </div>
                
                <div class="d-flex align-items-start">
                    <div class="feature-icon me-3 mb-0">
                        <i class="bi bi-clock-fill"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">Режим работы</h5>
                        <p class="text-muted mb-0">Пн-Пт: 9:00 - 18:00<br>Сб-Вс: по договоренности</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="card border-0 shadow-lg">
                    <div class="card-body p-4 p-lg-5">
                        <h3 class="fw-bold mb-4">Заказать обратный звонок</h3>
                        <form id="contactForm" method="post">
                            <div class="mb-3">
                                <label for="name" class="form-label">Ваше имя</label>
                                <input type="text" class="form-control" id="name" name="name" required placeholder="Иван Иванов">
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Телефон</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required placeholder="+7 (___) ___-__-__">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="example@mail.ru">
                            </div>
                            <div class="mb-3">
                                <label for="message" class="form-label">Сообщение</label>
                                <textarea class="form-control" id="message" name="message" rows="4" placeholder="Опишите ваш проект..."></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary-custom w-100 py-3">
                                Отправить заявку
                            </button>
                            <small class="text-muted d-block mt-3 text-center">
                                Нажимая кнопку, вы соглашаетесь с политикой конфиденциальности
                            </small>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section class="py-5">
    <div class="container-fluid px-0">
        <div style="height: 400px; background: #e9ecef; display: flex; align-items: center; justify-content: center;">
            <div class="text-center">
                <i class="bi bi-map fs-1 text-muted mb-3 d-block"></i>
                <p class="text-muted">Здесь будет интерактивная карта Яндекс или Google</p>
                <p class="small text-muted">г.Пенза ул.Ленинградская, 6</p>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();
