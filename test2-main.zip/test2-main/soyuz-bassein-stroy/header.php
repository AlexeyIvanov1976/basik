<?php
/**
 * The header template
 *
 * @package СоюзБассейнСтрой
 */

$phone = get_theme_mod('soyuz_phone', '+79677018686');
$email = get_theme_mod('soyuz_email', 'info@союзбассейнстрой.рф');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <!-- Top Bar -->
    <div class="top-bar bg-light py-2 d-none d-lg-block">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small><i class="bi bi-geo-alt-fill me-2"></i>г.Пенза ул.Ленинградская, 6</small>
                </div>
                <div class="col-md-6 text-end">
                    <a href="tel:<?php echo esc_attr($phone); ?>" class="text-decoration-none me-3">
                        <i class="bi bi-telephone-fill me-1"></i><?php echo esc_html($phone); ?>
                    </a>
                    <a href="mailto:<?php echo esc_attr($email); ?>" class="text-decoration-none">
                        <i class="bi bi-envelope-fill me-1"></i><?php echo esc_html($email); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                <?php
                if (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    echo '<span class="text-primary">СоюзБассейнСтрой</span>';
                }
                ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'navbar-nav ms-auto',
                    'container'      => false,
                    'depth'          => 2,
                    'fallback_cb'    => 'wp_page_menu',
                ));
                ?>
                <a href="tel:<?php echo esc_attr($phone); ?>" class="btn btn-primary-custom ms-lg-3 d-none d-lg-inline-block">
                    <i class="bi bi-telephone-fill me-1"></i>Заказать звонок
                </a>
            </div>
        </div>
    </nav>
</header>
